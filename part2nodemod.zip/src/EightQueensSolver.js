// Implementación del solucionador de las 8 reinas en JavaScript
// Basado en el algoritmo DFS con backtracking

class Queen {
  constructor(row, col, parent = null) {
    this.row = row;
    this.col = col;
    this.parent = parent;
  }

  nextSibling() {
    const max = 8;
    for (let c = this.col + 1; c <= max; c++) {
      const q = new Queen(this.row, c, this.parent);
      if (q.isValid()) {
        return q;
      }
    }
    return null;
  }

  firstChild() {
    const max = 8;
    if (this.row >= max) return null;

    for (let c = 1; c <= max; c++) {
      const q = new Queen(this.row + 1, c, this);
      if (q.isValid()) {
        return q;
      }
    }
    return null;
  }

  isValid() {
    let par = this.parent;
    while (par !== null) {
      if (par.col === this.col) return false;
      if (Math.abs(par.row - this.row) === Math.abs(par.col - this.col)) return false;
      par = par.parent;
    }
    return true;
  }
}

class Graph {
  constructor(root) {
    this.root = root;
  }

  *depthFirst() {
    let last = this.root;
    while (last !== null) {
      yield last;

      let child = last.firstChild();
      if (child !== null) {
        last = child;
      } else {
        let sibling = last.nextSibling();
        while (sibling === null && last.parent !== null) {
          last = last.parent;
          sibling = last.nextSibling();
        }
        last = sibling;
      }
    }
  }
}

export class EightQueensSolver {
  constructor() {
    this.nodesSearched = 0;
    this.solutions = [];
  }

  solve() {
    const graph = new Graph(new Queen(1, 1, null));
    for (const q of graph.depthFirst()) {
      this.nodesSearched++;
      if (q.row === 8) {
        this.makeSolution(q);
      }
    }
  }

  makeSolution(q) {
    const board = Array(8).fill().map(() => Array(8).fill(false));
    let current = q;
    while (current !== null) {
      board[current.row - 1][current.col - 1] = true;
      current = current.parent;
    }
    this.solutions.push(board);
  }
}
