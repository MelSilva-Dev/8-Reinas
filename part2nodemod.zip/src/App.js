import React, { useState } from 'react';
import Chessboard from './Chessboard';
import { EightQueensSolver } from './EightQueensSolver';
import './App.css';

function App() {
  const [solutions, setSolutions] = useState([]);
  const [currentSolution, setCurrentSolution] = useState(0);
  const [isSolving, setIsSolving] = useState(false);
  const [nodesSearched, setNodesSearched] = useState(0);

  const solve = () => {
    if (solutions.length > 0) return; // No resolver si ya hay soluciones

    setIsSolving(true);
    setSolutions([]);
    setCurrentSolution(0);
    setNodesSearched(0);

    // Resolución instantánea
    setTimeout(() => {
      const solver = new EightQueensSolver();
      solver.solve();
      setSolutions(solver.solutions);
      setNodesSearched(solver.nodesSearched);
      setIsSolving(false);
    }, 100);
  };

  const nextSolution = () => {
    if (solutions.length > 0) {
      setCurrentSolution((prev) => (prev + 1) % solutions.length);
    }
  };

  const prevSolution = () => {
    if (solutions.length > 0) {
      setCurrentSolution((prev) => (prev - 1 + solutions.length) % solutions.length);
    }
  };

  const currentBoard = solutions[currentSolution] || Array(8).fill().map(() => Array(8).fill(false));

  return (
    <div className="App">
      <header className="App-header">
        <h1>Visualizador del Problema de las 8 Reinas</h1>
        <p>Algoritmo DFS con Backtracking - Encuentra todas las 92 soluciones</p>
        <p className="description">
          El problema de las 8 reinas consiste en colocar 8 reinas en un tablero de ajedrez de 8x8
          de manera que ninguna reina ataque a otra. Esto significa que no pueden estar en la misma fila,
          columna o diagonal.
        </p>
      </header>

      <main>
        <div className="controls">
          <button onClick={solve} disabled={isSolving || solutions.length > 0}>
            {solutions.length > 0 ? 'Soluciones cargadas' : isSolving ? 'Resolviendo...' : 'Resolver'}
          </button>

          {solutions.length > 0 && (
            <>
              <button onClick={prevSolution}>Anterior</button>
              <button onClick={nextSolution}>Siguiente</button>
              <span>
                Solución {currentSolution + 1} de {solutions.length}
              </span>
            </>
          )}
        </div>

        <Chessboard board={currentBoard} />

        {solutions.length > 0 && (
          <div className="stats">
            <p>Total de soluciones encontradas: {solutions.length}</p>
            <p>Nodos explorados: {nodesSearched}</p>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${(currentSolution + 1) / solutions.length * 100}%` }}
              ></div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
