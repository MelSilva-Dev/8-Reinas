import React from 'react';
import './Chessboard.css';

const Chessboard = ({ board, onSquareClick }) => {
  return (
    <div className="chessboard">
      {board.map((row, rowIndex) => (
        <div key={rowIndex} className="row">
          {row.map((square, colIndex) => (
            <div
              key={colIndex}
              className={`square ${(rowIndex + colIndex) % 2 === 0 ? 'light' : 'dark'}`}
              onClick={() => onSquareClick && onSquareClick(rowIndex, colIndex)}
            >
              {square && <span className="queen">♛</span>}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default Chessboard;
