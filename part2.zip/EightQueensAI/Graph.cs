using System.Collections.Generic;

namespace EightQueensAI
{
    // ============================================================
    //  CLASE GRAPH<T> – DFS depthFirst() SEGÚN EL PATRÓN DEL PDF
    //  (Implementa el patrón de búsqueda en profundidad con backtracking)
    // ============================================================
    public class Graph<T> where T : class, IGNode<T>
    {
        private readonly T root;

        public Graph(T root)
        {
            this.root = root;
        }

        // ------------------ BASADO EN EL PDF ----------------------
        // depthFirst() sigue la lógica descrita en "Depth First Search"
        // del libro: avanzar al primer hijo, si no hay, nextSibling,
        // si no hay, subir al parent, etc.
        // ----------------------------------------------------------
        public IEnumerable<T> depthFirst()
        {
            T? last = root;

            while (last != null)
            {
                // devolvemos el nodo actual
                yield return last;

                // intentar bajar al primer hijo
                T? child = last.firstChild();

                if (child != null)
                {
                    last = child;
                }
                else
                {
                    // no hay hijo: intentamos con el siguiente hermano
                    T? sibling = last.nextSibling();

                    // si no hay hermano, retrocedemos al parent hasta encontrar uno
                    while (sibling == null && last.parent != null)
                    {
                        last = last.parent;
                        sibling = last.nextSibling();
                    }

                    last = sibling;
                }
            }
        }
    }
}
