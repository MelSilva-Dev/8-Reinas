namespace EightQueensAI
{
    // ------------------------------------------------------------
    // Interfaz de nodos de grafo, coherente con el uso en el PDF.
    // (Diseño propio, pero siguiendo el patrón del libro)
    // ------------------------------------------------------------
    public interface IGNode<T>
    {
        T? firstChild();
        T? nextSibling();
        T? parent { get; set; }
    }
}
