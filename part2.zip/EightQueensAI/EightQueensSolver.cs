using System;
using System.Collections.Generic;

namespace EightQueensAI
{
    // ============================================================
    //  SOLVER – USA solveDFS() COMO EN EL PDF + IMPRESIÓN
    //  Aplica SRP (esta clase solo se encarga de orquestar la búsqueda
    //  y gestionar soluciones).
    // ============================================================
    public class EightQueensSolver
    {
        public int nodesSearched = 0;
        public List<bool[,]> solutions = new List<bool[,]>();

        // ------------------ BASADO EN EL PDF ----------------------
        // Método solveDFS inspirado en el ejemplo:
        // Graph<Queen> queenGraph = new Graph<Queen>(new Queen(1, 1, null));
        // foreach (Queen q in queenGraph.depthFirst()) { ... }
        // ----------------------------------------------------------
        public void Solve()
        {
            Graph<Queen> queenGraph = new Graph<Queen>(new Queen(1, 1, null));

            // solve via depthFirst search
            foreach (Queen q in queenGraph.depthFirst())
            {
                nodesSearched++;

                // cuando row == max, tenemos una reina en la última fila:
                // eso significa una solución completa.
                if (q.row == Queen.max)
                {
                    MakeSolution(q);
                }
            }
        }

        // Reconstruye la solución desde la última reina hacia arriba usando parent.
        private void MakeSolution(Queen q)
        {
            bool[,] board = new bool[Queen.max, Queen.max];

            Queen? current = q;
            while (current != null)
            {
                // Las filas y columnas van de 1..max en Queen, ajustamos a 0..max-1
                board[current.row - 1, current.col - 1] = true;
                current = current.parent;
            }

            solutions.Add(board);

            PrintBoard(board);
            Console.WriteLine();
        }

        // Imprime el tablero en consola.
        private void PrintBoard(bool[,] board)
        {
            for (int r = 0; r < Queen.max; r++)
            {
                for (int c = 0; c < Queen.max; c++)
                {
                    Console.Write(board[r, c] ? " Q " : " . ");
                }
                Console.WriteLine();
            }
        }
    }
}
