﻿using System;

namespace EightQueensAI
{
    // ============================================================
    //  PROGRAMA PRINCIPAL
    //  Punto de entrada. Aplica SRP: solo arranca la solución
    //  y muestra el resumen de resultados.
    // ============================================================
    public static class Program
    {
        public static void Main()
        {
            var solver = new EightQueensSolver();
            solver.Solve();

            Console.WriteLine("Total de soluciones encontradas: " + solver.solutions.Count);
            Console.WriteLine("Nodos explorados (DFS): " + solver.nodesSearched);

            Console.WriteLine("Presiona una tecla para salir...");
            Console.ReadKey();
        }
    }
}
