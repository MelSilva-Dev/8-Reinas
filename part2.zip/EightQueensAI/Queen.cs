using System;

namespace EightQueensAI
{
    // ============================================================
    //  CLASE QUEEN – TOMADA DEL PDF "Design Patterns for Searching in C#"
    //  (Capítulo 3 – Depth First Search, ejemplo 8-Queens)
    // ============================================================
    public class Queen : IGNode<Queen>
    {
        public static int max = 8; //number of rows/cols in the chessboard
        // 8, for 8-Queens problem

        public int row = 1; //that this queen is on
        public int col = 1; //that this queen is on

        Queen? theParent = null; //queen on row just above this one in the solution so far

        public Queen(int r, int c, Queen? p)
        {
            row = r;
            col = c;
            parent = p;
        }

        // ------------------ TOMADO DEL PDF ------------------------
        public Queen? nextSibling()
        {
            //make a valid queen on the same row, but in next col.

            Queen q = new Queen(row, 1, parent);
            for (q.col = this.col + 1; q.col <= max; q.col++)
            {
                if (q.isValid())
                    return q;
            }
            return null;
        }
        // ----------------------------------------------------------

        public Queen? parent
        {
            get
            {
                return theParent;
            }
            set
            {
                theParent = value;
            }
        }

        // ------------------ TOMADO DEL PDF ------------------------
        public Queen? firstChild()
        {
            if (row >= max)
                return null;

            //make a valid queen on the next row
            Queen q = new Queen(row + 1, 1, this);

            for (q.col = 1; q.col <= max; q.col++)
            {
                if (q.isValid())
                    return q;
            }
            return null;
        }
        // ----------------------------------------------------------

        // ------------------ TOMADO DEL PDF ------------------------
        public bool isValid()
        {
            Queen? par = parent;

            //see if any queen on a row above this one could
            //capture this queen.
            while (par != null)
            {
                if (par.col == this.col)
                    return false;

                if (Math.Abs(par.row - row) == Math.Abs(par.col - col))
                    return false; //diag capture

                par = par.parent;
            }
            return true;
        }
        // ----------------------------------------------------------
    }
}
