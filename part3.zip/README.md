# ♟️ Problema de las 8 Reinas - Solver + Visualizador

## 📋 Descripción

Repositorio que contiene una implementación completa del clásico "Problema de las 8 Reinas" y un visualizador web. El solver en C# está basado en una búsqueda en profundidad (DFS / backtracking) usando un grafo de nodos (patrón tomado del libro de referencia). El visualizador es una pequeña aplicación React que muestra soluciones y permite experimentar con tableros.

El proyecto está pensado con separación de responsabilidades: la lógica de búsqueda y las entidades están en `EightQueensAI`, y la UI/visualización en `eight-queens-visualizer`.

## 🎮 Características

- ✅ Solver por DFS/backtracking (clásico, completo y determinista)
- ✅ Reconstrucción de soluciones mediante referencia a `parent`
- ✅ Conteo de soluciones y medición de nodos explorados
- ✅ Visualizador React para mostrar soluciones y explorar tableros
- ✅ Código simple y fácil de extender (buena base para experimentar con heurísticas o algoritmos más avanzados)

## 🧠 Algoritmo

- Tipo: Búsqueda en profundidad (Depth-First Search) con backtracking
- Implementación: `Graph<T>.depthFirst()` itera sobre nodos creados por `Queen.firstChild()` / `Queen.nextSibling()`
- Representación de estado: cada `Queen` contiene `row`, `col` y referencia a su `parent`. Cuando `row == max` se reconstruye la solución caminando por `parent`.
- Resultado: lista de tableros con posiciones de reinas (`List<bool[,]> solutions`) y contador de nodos explorados (`nodesSearched`).

## 🏗️ Estructura del Proyecto

```
Problema de las 8 reinas - Mel/
├── EightQueensAI/                # Solver en C# (.NET)
│   ├── EightQueensAI.csproj
│   ├── EightQueensSolver.cs      # Orquesta la búsqueda y almacena soluciones
│   ├── Graph.cs                  # Implementa depth-first traversal
│   ├── Queen.cs                  # Nodo/estado del problema
│   ├── IGNode.cs                 # Interfaz de nodos genéricos
│   └── Program.cs                # Punto de entrada (ejecuta el solver)

├── eight-queens-visualizer/      # Visualizador en React
│   ├── package.json
│   ├── public/
│   └── src/
│       ├── Chessboard.js         # Render del tablero (UI)
│       └── EightQueensSolver.js  # API/cliente ligero para consumir soluciones

├── Problema de las 8 reinas.sln
└── README.md
```

> Nota: Usa `EightQueensAI` como ejemplo de diseño sencillo para problemas de búsqueda; es una buena base para añadir heurísticas, poda o algoritmos alternativos.

## 🎯 Principios y Buenas Prácticas Aplicadas

- **Single Responsibility (SRP)**: `Queen` gestiona el estado del nodo; `Graph` la traversa; `EightQueensSolver` orquesta la búsqueda y la reconstrucción de soluciones.
- **Código modular**: separación clara entre motor (C#) y visualizador (React).
- **Patrón de diseño**: el enfoque de `Graph<T>` + `IGNode<T>` es una forma genérica de expresar búsquedas (facilita reusar la infraestructura para otros problemas).

## 🧪 Resultados y Métricas (ejecución de ejemplo)

Al ejecutar el solver (con `Queen.max = 8`) se obtiene:

- Número de soluciones encontradas: (imprimido por `Program`)
- Nodos explorados: contador `nodesSearched` durante DFS

Los resultados exactos se muestran en consola tras la ejecución.

## 🚀 Cómo Ejecutar

### Requisitos

- .NET SDK (la solución está configurada para `net9.0` en los binarios del workspace; usar .NET 9.0 SDK o .NET 8/9 según el SDK instalado)
- Node.js + npm (para el visualizador)

### Ejecutar el solver (C#)

Abre PowerShell y ejecuta:

```powershell
cd "c:\Users\melsi\OneDrive\Escritorio\Patrones de Software\EjerciciosSuplemen\Problema de las 8 reinas - Mel"
# Ejecutar directamente el proyecto C#
dotnet run --project .\EightQueensAI\EightQueensAI.csproj
```

El programa imprimirá cada solución encontrada y un resumen con el total de soluciones y nodos explorados.

### Ejecutar el visualizador (React)

```powershell
cd .\eight-queens-visualizer
npm install
npm start
```

El visualizador abre en `http://localhost:3000` (por defecto) y permite explorar soluciones y tableros.

## 🧩 Extensiones y Siguientes Mejoras Sugeridas

- Añadir heurísticas para reducción de búsqueda y poda (ej. symmetry breaking)
- Implementar y comparar otros enfoques: backtracking con ordenamiento de columnas, algoritmos de CSP (constraint propagation), algoritmos local search (hill-climbing / GA)
- Exportar soluciones desde el solver a JSON para que el visualizador las cargue dinámicamente
- Añadir tests unitarios y pruebas de rendimiento (benchmarking para distintos `Queen.max`)

## 🧾 Pruebas

Actualmente no hay un runner de pruebas automatizado en el repo; para validar manualmente:

- Ejecutar el solver y comprobar número de soluciones y nodos explorados
- Abrir el visualizador y comprobar que las soluciones se muestran correctamente

## 📚 Referencias

- Ejemplo base: "Design Patterns for Searching in C#" (ejemplo DFS y 8-Queens)
- Materiales clásicos sobre el Problema de las 8 Reinas y técnicas de backtracking

## 👥 Autor

- Código base en este repo

## 📝 Licencia

Asegura añadir un archivo `LICENSE` si deseas publicar con una licencia específica (MIT, Apache, etc.).

---

## Archivo creado
- `README.md` (este archivo) en la raíz del proyecto.

Si quieres, puedo:
- Añadir badges (build/status) y screenshots del visualizador
- Exportar soluciones a JSON para que el visualizador las consuma automáticamente
- Añadir un pequeño script de pruebas y `README` dentro de `eight-queens-visualizer` para documentar su uso más en detalle

¿Qué quieres que haga a continuación?